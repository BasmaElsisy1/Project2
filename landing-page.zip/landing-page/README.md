# Landing page

Its a code that helps the user to go to the specific section he wants with one click without scrolling to it. 
and it consist of **helper functions** to meet its desire.

## Steps:

- First trying to define every variable i have to make it easy for me to mention them in the functions
- Then creating helper function for adding links ( with every new section there is a new link in the navbar appeares)
- then creatig another function for scrolling to those sections
- then to make the selected section appeares, add to it a class with specific css elements
