// Define my variables
const container = document.querySelector("ul");
const fragment = document.createDocumentFragment();
const sections = document.querySelectorAll("section");
const dataNavs = document.querySelectorAll("[data-nav]");

// creating function for creating new <il> and <a> tags and add them to fragement and then adding this function to the parent
function menu() {
  for(const section of sections) {
    const li = document.createElement("li");
    const a = document.createElement("a");
    a.textContent = section.id;
    li.appendChild(a);
    fragment.append(li);
    scrolling(li, section);
  }
  return fragment
}
container.append(menu());

// creating helper function for scrolling
function scrolling(itemClicked, ItemScroll) {
  itemClicked.addEventListener("click", (a)=>{
    a.preventDefault();
    ItemScroll.scrollIntoView({ behavior: "smooth"});
  })
}

// add active class to the links
let buttons = document.querySelectorAll("a");
buttons.forEach((a) => {
    a.addEventListener("click", function () {
        buttons.forEach((a) => a.classList.remove("active"));
        this.classList.add("active");
    });
});

/**
 * In the viewport detection helper function for adding the active class 
 * 
*/
function viewing(section) {
  let rect = section.getBoundingClientRect();  
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth) &&
    rect.top <= (window.innerHeight || document.documentElement.clientHeight)
    
);
}

/**
 * active class tto sections
 * 
*/
function checkActive() {
  sections.forEach(element => { 
    element.classList.remove("myStyle");
  })
  sections.forEach(element => { 
    if (viewing(element)) {
      element.className = "myStyle";
    }
  })
}
// scroll event
window.addEventListener('scroll', checkActive)

